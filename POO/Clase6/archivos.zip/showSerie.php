<?php

require_once('autoload.php');

echo '<pre>';

$serie1 = new Serie('Samuray X');

var_dump($serie1);
