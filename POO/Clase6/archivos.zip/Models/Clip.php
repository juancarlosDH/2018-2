<?php

class Clip extends AudioVisual{

    
}
