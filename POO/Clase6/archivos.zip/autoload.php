<?php

require_once('Models/AudioVisual.php');
require_once('Models/Serie.php');
require_once('Models/Movie.php');
require_once('Models/Genre.php');
require_once('Models/Favorite.php');

//require_once('Models/peliculas.php');
