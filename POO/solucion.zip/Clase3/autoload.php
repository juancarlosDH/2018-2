<?php

require_once('Models/Movie.php');
require_once('Models/Genre.php');
require_once('Models/Favorite.php');
