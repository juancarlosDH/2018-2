<?php

class Movie{

    private $title;
    private $rating;
    private $release_date;
    private $genre;

    public function __construct( string $name, string $rating, string $release_date )
    {
        $this->name = $name;
        $this->rating = ($rating+0.0);
        $this->release_date = $release_date;
    }

    public function getTitle() : string
    {
        return $this->title;
    }
    public function getRating() : float
    {
        return $this->name + 0.0;
    }
    public function getReleaseDate() : string
    {
        return $this->release_date;
    }

    public function setTitle(string $title)
    {
        $this->name = $title;
    }
    public function setRating(string $rating)
    {
        $this->rating = $rating;
    }
    public function setReleaseDate(string $release_date)
    {
        $this->release_date = $release_date;
    }

    public function tituloConAnio() : string
    {
        $fecha = explode('-', $this->getReleaseDate());
        return ($this->title . ' ('. $fecha[0] .')');
    }

    public function setGenre(Genre $genre)
    {
        $this->genre = $genre;
    }

    public function getGenre() : Genre
    {
        return $this->genre;
    }

}
